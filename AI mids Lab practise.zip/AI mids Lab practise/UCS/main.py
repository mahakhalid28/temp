from graph import Graph

if __name__ == "__main__":
    g = Graph()
    g.addDirectedEdge("A", "B", 1)
    g.addDirectedEdge("A", "C", 1)
    g.addDirectedEdge("B", "D", 3)
    g.addDirectedEdge("C", "F", 2)
    g.addDirectedEdge("D", "F", 2)
    g.addDirectedEdge("D", "G", 4)
    g.addDirectedEdge("F", "E", 4)
    g.addDirectedEdge("F", "I", 1)
    g.addDirectedEdge("F", "A", 3)
    g.addDirectedEdge("I", "E", 1)
    g.addDirectedEdge("I", "J", 3)
    g.addDirectedEdge("E", "H", 5)
    g.addDirectedEdge("E", "G", 1)
    g.addDirectedEdge("J", "H", 1)
    g.addDirectedEdge("G", "H", 1)

    # Uniform Cost Search Algorithm
    path, cost = g.ucs("A", "H")
    print(f"Shortest path from A to H using UCS is with cost {cost}")
    g.printPath("H", path)
    print("\n")
