import heapq

# Maze grid: 'S' = start, 'E' = end, 1 = wall, 0 = free
maze = [["S", 0, 0, 0, 1], [1, 1, 0, 0, 1], [0, 0, 0, 1, 0], [0, 1, 0, 0, "E"]]

rows = len(maze)
cols = len(maze[0])

# Start and End
start = (0, 0)
end = (3, 4)


# Manhattan Distance Heuristic
def heuristic(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


# A* Search
def a_star(maze, start, end):
    queue = [(heuristic(start, end), 0, start, [start])]  # (f, g, node, path)
    visited = set()

    while queue:
        f, g, current, path = heapq.heappop(queue)

        if current == end:
            return path

        if current in visited:
            continue
        visited.add(current)

        # Directions: up, down, left, right
        for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            nx, ny = current[0] + dx, current[1] + dy

            if 0 <= nx < rows and 0 <= ny < cols and maze[nx][ny] != 1:
                neighbor = (nx, ny)
                if neighbor not in visited:
                    new_g = g + 1
                    new_f = new_g + heuristic(neighbor, end)
                    heapq.heappush(queue, (new_f, new_g, neighbor, path + [neighbor]))

    return None


# Run the search
path = a_star(maze, start, end)

# Output
if path:
    print("Shortest path:", path)
    print("Number of steps:", len(path) - 1)
else:
    print("No path found.")
