import math


class Node:
    def __init__(self, state, parent, actions, totalCost, heuristic):
        self.state = state  # Node name (e.g., 'A', 'B', etc.)
        self.parent = parent  # Parent node
        self.actions = actions  # Possible moves from this node
        self.totalCost = totalCost  # g(n): Cost from start to this node
        self.heuristic = heuristic  # Position coordinates for heuristic calculation


def findMin(frontier):
    """Find the node with minimum f(n) = g(n) + h(n) in the frontier"""
    minV = math.inf
    node = ""
    for i in frontier:
        if minV > frontier[i][1]:
            minV = frontier[i][1]
            node = i
    return node


def actionSequence(graph, initialState, goalState):
    """Reconstruct the path from start to goal"""
    solution = [goalState]
    currentParent = graph[goalState].parent
    while currentParent != None:
        solution.append(currentParent)
        currentParent = graph[currentParent].parent
    solution.reverse()
    return solution


def manhattanDistance(pos1, pos2):
    """Calculate Manhattan distance between two positions"""
    return abs(pos1[0] - pos2[0]) + abs(pos1[1] - pos2[1])


def Astar():
    """A* search implementation for the maze in Activity 1"""
    initialState = "A"
    goalState = "Y"

    # Create graph with nodes and their connections based on the maze
    # Format: Node(state, parent, [(neighbor, cost)], totalCost, (row, col))
    # The coordinates are based on the maze image with (0,0) at bottom-left
    graph = {
        "A": Node("A", None, [("F", 1)], 0, (0, 0)),
        "B": Node("B", None, [("G", 1), ("C", 1)], 0, (0, 2)),
        "C": Node("C", None, [("B", 1), ("D", 1)], 0, (0, 3)),
        "D": Node("D", None, [("C", 1), ("E", 1)], 0, (0, 4)),
        "E": Node("E", None, [("D", 1)], 0, (0, 5)),
        "F": Node("F", None, [("A", 1), ("H", 1)], 0, (1, 0)),
        "G": Node("G", None, [("B", 1), ("J", 1)], 0, (1, 2)),
        "H": Node("H", None, [("F", 1), ("I", 1), ("M", 1)], 0, (2, 0)),
        "I": Node("I", None, [("H", 1), ("J", 1), ("N", 1)], 0, (2, 1)),
        "J": Node("J", None, [("G", 1), ("I", 1), ("K", 1)], 0, (2, 2)),
        "K": Node("K", None, [("J", 1), ("L", 1), ("P", 1)], 0, (2, 4)),
        "L": Node("L", None, [("K", 1), ("Q", 1)], 0, (2, 5)),
        "M": Node("M", None, [("H", 1), ("N", 1), ("R", 1)], 0, (3, 0)),
        "N": Node("N", None, [("I", 1), ("M", 1), ("S", 1)], 0, (3, 1)),
        "O": Node("O", None, [("P", 1), ("U", 1)], 0, (3, 3)),
        "P": Node("P", None, [("K", 1), ("O", 1), ("Q", 1)], 0, (3, 4)),
        "Q": Node("Q", None, [("L", 1), ("P", 1), ("V", 1)], 0, (3, 5)),
        "R": Node("R", None, [("M", 1), ("S", 1)], 0, (4, 0)),
        "S": Node("S", None, [("N", 1), ("R", 1), ("T", 1)], 0, (4, 1)),
        "T": Node("T", None, [("S", 1), ("U", 1), ("W", 1)], 0, (4, 2)),
        "U": Node("U", None, [("O", 1), ("T", 1)], 0, (4, 3)),
        "V": Node("V", None, [("Q", 1), ("Y", 1)], 0, (4, 5)),
        "W": Node("W", None, [("T", 1)], 0, (5, 2)),
        "X": Node("X", None, [("Y", 1)], 0, (5, 4)),
        "Y": Node("Y", None, [("V", 1), ("X", 1)], 0, (5, 5)),
    }

    # Initialize frontier with the start node
    frontier = dict()
    heuristicCost = manhattanDistance(
        graph[initialState].heuristic, graph[goalState].heuristic
    )
    frontier[initialState] = (None, heuristicCost)

    # Initialize explored set
    explored = dict()

    while len(frontier) != 0:
        # Find node with minimum f(n)
        currentNode = findMin(frontier)

        # Remove from frontier
        del frontier[currentNode]

        # Goal test
        if graph[currentNode].state == goalState:
            return actionSequence(graph, initialState, goalState)

        # Compute heuristic for current node to goal
        heuristicCost = manhattanDistance(
            graph[goalState].heuristic, graph[currentNode].heuristic
        )

        # Current g(n)
        currentCost = graph[currentNode].totalCost

        # Mark as explored
        explored[currentNode] = (graph[currentNode].parent, heuristicCost + currentCost)

        # Expand the node - check all children
        for child in graph[currentNode].actions:
            childNode = child[0]
            stepCost = child[1]

            # Calculate new costs
            childTotalCost = currentCost + stepCost
            childHeuristicCost = manhattanDistance(
                graph[goalState].heuristic, graph[childNode].heuristic
            )

            # Check if already explored with better cost
            if childNode in explored:
                if explored[childNode][1] <= childTotalCost + childHeuristicCost:
                    continue

            # Check if already in frontier with better cost
            if childNode in frontier:
                if frontier[childNode][1] < childTotalCost + childHeuristicCost:
                    continue

            # Add to frontier or update if better path found
            graph[childNode].parent = currentNode
            graph[childNode].totalCost = childTotalCost
            frontier[childNode] = (
                graph[childNode].parent,
                childTotalCost + childHeuristicCost,
            )

    # No solution found
    return None


def printMaze(path=None):
    """Print the maze with the path marked"""
    # Create the maze representation
    maze = [
        ["#", "#", "W", "#", "X", "Y"],
        ["R", "S", "T", "U", "#", "V"],
        ["M", "N", "#", "O", "P", "Q"],
        ["H", "I", "J", "#", "K", "L"],
        ["F", "#", "G", "#", "#", "#"],
        ["A", "#", "B", "C", "D", "E"],
    ]

    # Mark the path in the maze
    if path:
        print("Path Found:", " -> ".join(path))

        # Create a copy of the maze to mark the path
        marked_maze = []
        for row in maze:
            marked_maze.append(row.copy())

        # Mark the path with '*' except for start and end
        for node in path[1:-1]:  # Skip start and end nodes
            # Find the node in the maze
            for i in range(len(maze)):
                for j in range(len(maze[0])):
                    if maze[i][j] == node:
                        marked_maze[i][j] = "*"

        # Print the maze with the path
        for row in marked_maze:
            print(" ".join(row))
    else:
        # Print the original maze
        for row in maze:
            print(" ".join(row))


# Run the A* search
if __name__ == "__main__":
    print("Maze Problem (Activity 1)")
    print("Initial state: A, Goal state: Y")
    print("\nOriginal Maze:")
    printMaze()

    path = Astar()

    if path:
        print("\nMaze with Path:")
        printMaze(path)
    else:
        print("\nNo path found!")
