import heapq
from typing import List, Tuple, Dict, Optional


class MazeSolver:
    def __init__(self, maze: List[List[str]]):
        """
        Initialize the maze solver with the maze grid.
        'R' = Robot start position (red)
        'G' = Goal position (green)
        '#' = Wall
        ' ' = Empty path
        """
        self.maze = maze
        self.start_pos = self.find_position("R")
        self.goal_pos = self.find_position("G")

        # Define possible movements (N, E, S, W)
        self.directions = {"N": (-1, 0), "E": (0, 1), "S": (1, 0), "W": (0, -1)}

    def find_position(self, marker: str) -> Tuple[int, int]:
        """Find the (row, col) position of a marker in the maze"""
        for i, row in enumerate(self.maze):
            for j, cell in enumerate(row):
                if cell == marker:
                    return (i, j)
        raise ValueError(f"Marker '{marker}' not found in maze")

    def heuristic(self, pos: Tuple[int, int]) -> int:
        """Manhattan distance heuristic from current position to goal"""
        return abs(pos[0] - self.goal_pos[0]) + abs(pos[1] - self.goal_pos[1])

    def get_neighbors(self, pos: Tuple[int, int]) -> List[Tuple[int, int]]:
        """Get valid neighboring positions that aren't walls"""
        neighbors = []
        for di, dj in self.directions.values():
            ni, nj = pos[0] + di, pos[1] + dj
            if 0 <= ni < len(self.maze) and 0 <= nj < len(self.maze[0]):
                if self.maze[ni][nj] != "#":
                    neighbors.append((ni, nj))
        return neighbors

    def solve(self) -> Tuple[List[Tuple[int, int]], int]:
        """
        Solve the maze using A* search.
        Returns:
            - path: List of coordinates from start to goal
            - cost: Total cost of the path (number of steps)
        """
        open_set = []
        heapq.heappush(open_set, (0, self.start_pos))

        came_from: Dict[Tuple[int, int], Optional[Tuple[int, int]]] = {}
        g_score = {self.start_pos: 0}
        f_score = {self.start_pos: self.heuristic(self.start_pos)}

        open_set_hash = {self.start_pos}

        while open_set:
            current = heapq.heappop(open_set)[1]
            open_set_hash.remove(current)

            if current == self.goal_pos:
                # Reconstruct path
                path = []
                while current in came_from:
                    path.append(current)
                    current = came_from[current]
                path.append(self.start_pos)
                path.reverse()
                return path, len(path) - 1  # Cost is number of steps

            for neighbor in self.get_neighbors(current):
                tentative_g_score = g_score[current] + 1

                if neighbor not in g_score or tentative_g_score < g_score[neighbor]:
                    came_from[neighbor] = current
                    g_score[neighbor] = tentative_g_score
                    f_score[neighbor] = tentative_g_score + self.heuristic(neighbor)
                    if neighbor not in open_set_hash:
                        heapq.heappush(open_set, (f_score[neighbor], neighbor))
                        open_set_hash.add(neighbor)

        return [], 0  # No path found


def print_maze_with_path(maze: List[List[str]], path: List[Tuple[int, int]]):
    """Print the maze with the path marked with '*'"""
    maze_copy = [row.copy() for row in maze]
    for step in path[1:-1]:  # Skip start and end positions
        i, j = step
        maze_copy[i][j] = "*"

    for row in maze_copy:
        print(" ".join(row))


# Example maze
maze = [
    ["#", "#", "#", "#", "#", "#", "#", "#", "#", "#"],
    ["#", "R", " ", " ", " ", "#", " ", " ", " ", "#"],
    ["#", "#", "#", " ", "#", "#", "#", "#", " ", "#"],
    ["#", " ", " ", " ", " ", " ", " ", " ", " ", "#"],
    ["#", " ", "#", "#", "#", "#", "#", " ", "#", "#"],
    ["#", " ", " ", " ", " ", " ", "#", " ", " ", "#"],
    ["#", "#", "#", "#", "#", " ", "#", "#", " ", "#"],
    ["#", " ", " ", " ", " ", " ", " ", " ", "G", "#"],
    ["#", "#", "#", "#", "#", "#", "#", "#", "#", "#"],
]

if __name__ == "__main__":
    solver = MazeSolver(maze)
    path, cost = solver.solve()

    if path:
        print("Path found!")
        print("Path coordinates:", path)
        print("Path cost (steps):", cost)
        print("\nMaze with path marked:")
        print_maze_with_path(maze, path)
    else:
        print("No path found to the goal!")
