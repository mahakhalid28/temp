import heapq


def heuristic(a, b):
    """Calculate Manhattan distance between two points"""
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


def a_star_search(grid, start, end):
    """Perform A* search on the grid from start to end"""

    # Directions: up, down, left, right
    neighbors = [(0, 1), (1, 0), (0, -1), (-1, 0)]

    close_set = set()
    came_from = {}
    gscore = {start: 0}
    fscore = {start: heuristic(start, end)}
    oheap = []
    heapq.heappush(oheap, (fscore[start], start))

    while oheap:
        current = heapq.heappop(oheap)[1]

        if current == end:
            path = []
            while current in came_from:
                path.append(current)
                current = came_from[current]
            path.append(start)
            path.reverse()
            return path

        close_set.add(current)

        for i, j in neighbors:
            neighbor = current[0] + i, current[1] + j

            # Check if neighbor is within grid bounds
            if 0 <= neighbor[0] < len(grid) and 0 <= neighbor[1] < len(grid[0]):
                # Check if neighbor is not a wall
                if grid[neighbor[0]][neighbor[1]] == 1:
                    continue
            else:
                # Out of bounds
                continue

            if neighbor in close_set:
                continue

            tentative_g_score = gscore[current] + 1

            if neighbor not in [i[1] for i in oheap]:
                heapq.heappush(oheap, (fscore.get(neighbor, float("inf")), neighbor))
            elif tentative_g_score >= gscore.get(neighbor, float("inf")):
                continue

            came_from[neighbor] = current
            gscore[neighbor] = tentative_g_score
            fscore[neighbor] = gscore[neighbor] + heuristic(neighbor, end)

    return None  # No path found


def solve_maze(grid, start, end):
    """Solve the maze and return the path"""
    # Convert grid to binary representation (0 = walkable, 1 = wall)
    binary_grid = []
    for row in grid:
        binary_row = []
        for cell in row:
            if cell == "S":
                binary_row.append(0)
                start_pos = (len(binary_grid), len(binary_row) - 1)
            elif cell == "E":
                binary_row.append(0)
                end_pos = (len(binary_grid), len(binary_row) - 1)
            elif cell == "#":
                binary_row.append(1)
            else:
                binary_row.append(0)
        binary_grid.append(binary_row)

    # If start and end positions weren't specified, use the ones we found
    if not start:
        start = start_pos
    if not end:
        end = end_pos

    path = a_star_search(binary_grid, start, end)

    if path:
        # Create a copy of the grid to mark the path
        solved_grid = [row.copy() for row in grid]
        for step in path[1:-1]:  # Skip start and end positions
            solved_grid[step[0]][step[1]] = "."
        return solved_grid, path
    else:
        return None, None


# Example usage:
if __name__ == "__main__":
    # Example maze (S = start, E = end, # = wall, ' ' = empty path)
    maze = [
        ["S", "#", "#", "#", "#"],
        [" ", " ", " ", " ", "#"],
        ["#", " ", "#", "#", "#"],
        [" ", " ", " ", " ", "#"],
        ["#", " ", "#", " ", "E"],
    ]

    # Find start and end positions
    start_pos = None
    end_pos = None
    for i in range(len(maze)):
        for j in range(len(maze[i])):
            if maze[i][j] == "S":
                start_pos = (i, j)
            elif maze[i][j] == "E":
                end_pos = (i, j)

    solved_maze, path = solve_maze(maze, start_pos, end_pos)

    if solved_maze:
        print("Path found! Steps:", len(path) - 1)
        print("Path coordinates:", path)
        print("Maze with path marked:")
        for row in solved_maze:
            print(" ".join(row))
    else:
        print("No path found!")
