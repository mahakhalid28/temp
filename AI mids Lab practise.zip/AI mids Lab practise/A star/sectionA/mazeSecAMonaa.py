import heapq

# Maze grid: 'S' = start, 'E' = end, 1 = wall, 0 = free
maze = [
    ["#", "#", "W", "#", "X", "Y"],
    ["R", "S", "T", "U", "#", "V"],
    ["M", "N", "#", "O", "P", "Q"],
    ["H", "I", "J", "#", "K", "L"],
    ["F", "#", "G", "#", "#", "#"],
    ["A", "#", "B", "C", "D", "E"],
]

rows = len(maze)
cols = len(maze[0])

# Start and End
start = (5, 0)
end = (0, 5)


# Manhattan Distance Heuristic
def heuristic(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


# A* Search
def a_star(maze, start, end):
    queue = [(heuristic(start, end), 0, start, [start])]  # (f, g, node, path)
    visited = set()

    while queue:
        f, g, current, path = heapq.heappop(queue)

        if current == end:
            return path

        if current in visited:
            continue
        visited.add(current)

        # Directions: up, down, left, right
        for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            nx, ny = current[0] + dx, current[1] + dy

            if 0 <= nx < rows and 0 <= ny < cols and maze[nx][ny] != 1:
                neighbor = (nx, ny)
                if neighbor not in visited:
                    new_g = g + 1
                    new_f = new_g + heuristic(neighbor, end)
                    heapq.heappush(queue, (new_f, new_g, neighbor, path + [neighbor]))

    return None


# Run the search
path = a_star(maze, start, end)


# Run the search
path = a_star(maze, start, end)

# Output
if path:
    print("Shortest path (coordinates):", path)
    print("Number of steps:", len(path) - 1)

    # Get letters from path
    letter_path = [maze[x][y] for x, y in path]
    print("Shortest path (letters):", " -> ".join(letter_path))
else:
    print("No path found.")
