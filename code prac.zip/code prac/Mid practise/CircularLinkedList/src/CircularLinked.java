public class CircularLinked {
    Node head;
    Node tail;
    public class Node{
        int data;// data ko as a id treat krlena
        Node next;
        int time;
        public Node( int data,int time){
            this.data=data;
            this.next=null;
            this.time=time;

        }
        public Node( int data){
            this.data=data;
            this.next=null;
            this.time=0;

        }
    }
   /* public void insertAtEnd(int element,int  time){
        Node newNode= new Node(element,time);
        if(head==null){
            head=newNode;
            tail=newNode;
            newNode.next=head;
            return;
        }
        tail.next=newNode;
        newNode.next=head;
        tail = newNode;
    }*/
   public void insertAtStart(int element){
        Node newNode= new Node(element);
        if(head==null){
            head=newNode;
            tail=newNode;
            return;
        }
        newNode.next=head;
        head=newNode;
        tail.next = head;
    }
    public void insertAtLoc(int element,Node n){
        Node newNode= new Node(element);
        if(head==n){
            insertAtStart(element);
            return;
        }
        if(n==tail){
            insertAtEnd(element);
            return;
        }
     Node result=n.next;
        n.next=newNode;
        newNode.next=result;
    }
    public void deleteAtStart(){
        if(head==null){
            System.out.println("list is empty");
            return;
        }
        if(head.next==null){
            head=null;
            tail=null;
        }
        head=head.next;
        tail.next=head;
    }
    public void deleteAt(Node nodeToDel){
        if(nodeToDel==head)
        {
            deleteAtStart();
            return;
        }
        if(nodeToDel==tail){
            deleteAtEnd();
            return;
        }
        Node curr=head;
        Node prev=null;
        while(curr!=nodeToDel){
            prev=curr;
            curr=curr.next;
        }
        prev.next=curr.next;




    }
    public void deleteAtEnd(){
        Node temp=head;
        if(head==null){
            System.out.println("list is empty");
            return;
        }
        if(head.next==null){
            head=null;
            tail=null;
            return;

        }
        while(temp.next!=tail){
            temp=temp.next;
        }
        temp.next=head;
        tail=temp;
    }

    public  void display(){
       Node temp=head;
       while(temp.next!=head){
           System.out.print(temp.data + " ");
           temp=temp.next;
       }
        System.out.println(temp.data);
    }
    public void insertAtEnd(int element) {
        Node newNode = new Node(element);
        if (head == null) {
            head = newNode;
            tail = newNode;
            newNode.next = head;
            return;
        }
        tail.next = newNode;
        newNode.next = head;
        tail = newNode;
    }
    public void roundRobin(int quanta){
        Node temp=head;
        while(temp.next!=head){
            temp.time=temp.time-quanta;
            if(temp.time<=0){
                Node nodeToDelete = temp;
                temp=temp.next;
                deleteAt(nodeToDelete);
            }else{
                temp=temp.next;
            }
        }
        if(temp.time<=0){
            Node nodeToDelete = temp;
            deleteAt(nodeToDelete);
        }
    }


    public static void main(String[] args) {
        CircularLinked cl= new CircularLinked();
        cl.insertAtEnd(2);
        cl.insertAtEnd(3);
        cl.insertAtEnd(4);
        cl.insertAtStart(1);
         cl.insertAtLoc(9, cl.head.next);

       /* cl.insertAtEnd(1,1);
        cl.insertAtEnd(2,2);
        cl.insertAtEnd(3,4);
        cl.insertAtEnd(4,5);*/
        cl.display();
      //  cl.roundRobin(3);
        //cl.display();
    }
}
