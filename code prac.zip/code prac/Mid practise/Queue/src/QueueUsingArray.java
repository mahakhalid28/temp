public class QueueUsingArray {
    int[]array= new int [10];
    int back;
    public void enqueue(int element){
        array[back] = element;
        back++;
    }
    public int dequeue(){
        int result = array[0];
        back--;
        for(int i =0; i < back; i++){
            array[i] = array[i+1];
        }
        return result;
    }
    public boolean isEmpty(){
        return back==0;
    }

    public static void main(String[] args) {
        QueueUsingArray q= new QueueUsingArray();
        q.enqueue(2);
        q.enqueue(3);
        q.enqueue(4);
        q.enqueue(5);
        while(!q.isEmpty()){
            System.out.println( q.dequeue());

        }


    }
}
