public class QueueUsingStacks {

    public void enqueue(){

    }


}
