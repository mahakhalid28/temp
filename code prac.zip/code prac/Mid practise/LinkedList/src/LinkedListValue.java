public class LinkedListValue {
    Node head;
    Node tail;

    public class Node {
        int data;
        Node next;

        public Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    public boolean Search(int value) {
        Node temp = head;
        while (temp != null) {
            if (temp.data == value) {
                return true;
            }
            temp = temp.next;

        }
        return false;

    }
    public void addAtLast(int data) {
        Node newNode = new Node(data);
        if (tail == null) {
            head = newNode;
            tail = newNode;
        } else {
            tail.next = newNode;
            tail = newNode;
        }
    }
    public int lengthOfList(){
      Node  temp=head;
      int count=0;
      while(temp!=null){
          count++;
          temp=temp.next;

      }
      return count;
    }

    public static void main(String[] args) {
        LinkedListValue val = new LinkedListValue();
        val.addAtLast(3);
        val.addAtLast(1);
        val.addAtLast(2);
        System.out.println(val.Search(2));
        System.out.println(val.lengthOfList());


    }
}





