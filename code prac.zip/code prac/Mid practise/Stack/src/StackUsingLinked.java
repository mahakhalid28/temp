public class StackUsingLinked {
    Node head;
    Node tail;

    public static class Node {
        int data;
        Node next;


        public Node(int data) {
            this.data = data;
            this.next = null;
        }

    }

    public void push(int data) {
        Node temp = head;

        Node newNode = new Node(data);
        if (tail == null) {
            head = newNode;
            tail = newNode;
        } else {

            tail.next = newNode;
            tail = newNode;

        }

    }

    public int pop() {
        if (tail == null) {
            System.out.println("stack is empty");
            return -1;
        }
        int val = tail.data;
        if (head.next == null) {
            tail = null;
            head = null;
        } else {
            Node temp = head;
            while (temp.next != tail) {
                temp = temp.next;
            }
            tail = temp;
            tail.next = null;
        }
        return val;

    }

    public boolean isEmpty() {
        return head == null;
    }


    public static void main(String[] args) {
        StackUsingLinked s = new StackUsingLinked();
        s.push(1);
        s.push(3);
        s.push(4);
        while (!s.isEmpty()) {
            System.out.println(s.pop());
        }
    }
}

