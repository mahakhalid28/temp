//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.

public class Stack{
    int[]array= new int[10];
    int top;
    public int push(int element) {
        if (top >= array.length) {
            arrayCopy();
        }
        if (top < array.length) {
            array[top] = element;
            top++;
        }
        return top;
    }
    public void arrayCopy() {
        int[] newArray = new int[array.length * 2];
        for (int i = 0; i < array.length; i++) {
            newArray[i] = array[i];
        }
        this.array = newArray;
    }
    public int pop(){
        top--;
        return array[top];
    }
    public int size(){
        return top;
    }
    public boolean  isEmpty(){
        return size()==0;
    }

    public static void main(String[] args) {
        Stack s= new Stack();
        s.push(2);
        s.push(3);
        s.push(4);
        s.push(5);
        while(!s.isEmpty()){
            System.out.println(s.pop());
        }






    }
}






