import java.util.StringTokenizer;
import java.util.Stack;


public class InfixToPostFix {

    String output = "";

    public boolean isOperator(String s) {
        if (s.equals("+") || s.equals("-") || s.equals("*") || s.equals("/") || s.equals("^")) {
            return true;
        }
        return false;

    }

    public String Convert(String exp) {
        Stack<String> s = new Stack<>();
        StringTokenizer tokenizer = new StringTokenizer(exp);
        String token;
        while (tokenizer.hasMoreTokens()) {
            token = tokenizer.nextToken();
            if (token.equals("(")) {
                s.push("(");
            } else if (token.equals(")")) {
                String top = s.pop();
                while (!s.isEmpty() && !top.equals("(")) {
                    output = output + " " + top;
                    top = s.pop();
                }
            } else if (this.isOperator(token)) {
                while (!s.isEmpty() && isPrecedanceGreaterorEqual(s.peek(), token)) {
                    String top = s.pop();
                    output = output + " " + top;
                }
                s.push(token);
            } else {
                output = output + " " + token;
            }
        }
        while (!s.isEmpty()) {
            output = output + " " + s.pop();
        }
        return output;

    }

    public int Precedance(String op) {
        if (op.equals("^"))
            return 3;
        else if (op.equals("*") || op.equals("/"))
            return 2;
        else if (op.equals("+") || op.equals("-"))
            return 1;
        else return 0;


    }

    public boolean isPrecedanceGreaterorEqual(String op1, String op2) {
        return Precedance(op1) >= Precedance(op2);
    }

    public static void main(String[] args) {
        InfixToPostFix exp = new InfixToPostFix();
        String input = ("2 * 3 + 7 / 6");
        String x = exp.Convert(input);
        System.out.println(x);
    }
}

