import java.util.StringTokenizer;
import java.util.Stack;

public class reverseUsingStack {
    public String reverse(String input) {
        Stack<Character> s = new Stack<>();
        String output = "";
        for (int i = 0; i < input.length(); i++) {
            s.push(input.charAt(i));
        }
        while (!s.isEmpty()) {
            output += s.pop();
        }
        return output;
    }

    public static void main(String[] args) {
        reverseUsingStack string = new reverseUsingStack();
        String newString = string.reverse("hello");
        System.out.println(newString);
    }
}
