package stack;

public class Stack {

    int[] array = new int[10];
    int top = 0;

    public void push(int element) {
        if (top >= array.length) {
            arrayCopy();
        }
        if (top < array.length) {
            array[top] = element;
            top++;
        }

    }

    private void arrayCopy() {
        int[] newArray = new int[array.length * 2];
        for (int i = 0; i < array.length; i++) {
            newArray[i] = array[i];
        }
        this.array = newArray;
    }

    public int pop() {
        top--;
        return array[top];

    }

    public int size() {
        return top;
    }

    public boolean isEmpty() {
        return size() == 0;
    }

}