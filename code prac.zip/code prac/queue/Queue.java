package queue;

public class Queue {
    int array[];

}
// public class Queue {
// int[] array = new int[10];
// int back = 0;
// int element;
// int front = 0;

// public void push(int element) {
// if (back <= array.length) {
// array[back] = element;
// back++;

// }

// }

// public int pop() {
// int temp = array[0];
// for (int i = 0; i < back - 1; i++) {
// array[i] = array[i + 1];

// }
// back--;
// return temp;
// }

// // public int pop() {
// // if (front >= 0 && array[front] != Integer.MIN_VALUE) {
// // element = array[front];
// // front--;
// // } else {
// // System.out.println("dequee is empty");

// // }

// // }

// public boolean isEmpty() {
// return back == 0;
// }
// }
