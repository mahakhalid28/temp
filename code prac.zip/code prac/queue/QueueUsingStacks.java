package queue;

import java.util.Stack;

public class QueueUsingStacks {
    Stack<Integer> s1 = new Stack<>();
    Stack<Integer> s2 = new Stack<>();

    public void enqueue(int elem) {
        s1.push(elem);
    }

    public int dequeue() {
        while (!s1.empty()) {
            s2.push(s1.pop());
        }
        int elem = s2.pop();
        while (!s2.empty()) {
            s1.push(s2.pop());
        }
        return elem;
    }

    public boolean empty() {
        return s1.empty();
    }

    public static void main(String[] args) {
        QueueUsingStacks q = new QueueUsingStacks();
        q.enqueue(0);
        q.enqueue(1);
        q.enqueue(2);
        q.enqueue(3);
        q.enqueue(4);
        q.enqueue(5);

        while (!q.empty()) {
            System.out.println(q.dequeue());
        }
    }
}