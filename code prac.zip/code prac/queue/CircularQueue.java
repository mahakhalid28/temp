package queue;

public class CircularQueue {
    int[] array;
    int front = -1;
    int back = -1;

    public CircularQueue(int size) {
        array = new int[size];
    }

    public void enqueue(int elem) {
        if (isFull()) {
            System.out.println("cannot insert queue is full");
            return;
        }
        back = (back + 1) % array.length;
        array[back] = elem;
        if (front == -1) {
            front = 0;
        }
    }

    public int deque() {
        int result;
        if (isEmpty()) {
            System.out.println("Cannot dequeue queue is empty");
            return -1;
        }
        result = array[front];
        if (front == back) {
            front = -1;
            back = -1;
        } else {
            front = (front + 1) % array.length;
        }
        return result;
    }

    public boolean isFull() {
        return (back + 1) % array.length == front;
    }

    public boolean isEmpty() {
        return back == -1 && front == -1;
    }

    public int size() {
        if (front < back) {
            return back - front + 1;
        } else {
            return (array.length - front) + (back + 1);
        }
    }

    public static void main(String[] args) {
        CircularQueue queue = new CircularQueue(3);
        queue.enqueue(0);
        queue.enqueue(1);
        queue.enqueue(2);
        queue.enqueue(3);

        queue.deque();
        queue.enqueue(4);
        while (!queue.isEmpty()) {
            System.out.println(queue.deque());
        }
    }
}
