package queue;

public class CircularQueue {
    int[] array;
    int front = 0;
    int back = 0;

    public void isEmpty() {
        if (back < 0) {
            back = array.length;

        }

    }

}
