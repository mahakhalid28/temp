import java.util.Arrays;

public class ArrayElements {

    public static void main(String[] args) {

        int[] arrayA = { 2, 2, 5, 7, 17, 18, 6, 9, 5 };
        int[] arrayB = { 2, 2, 6, 7, 8, 11, 12, 14, 15 };
        int[] common = commonElemenets(arrayA, arrayB);
        int[] union = union(arrayA, arrayB);
        System.out.println(Arrays.toString(common));
        System.out.println(Arrays.toString(union));
    }

    static int[] commonElemenets(int[] arrayA, int[] arrayB) {
        int[] arrayC = new int[arrayA.length + arrayB.length];
        int idx = 0;

        for (int elemA : arrayA) {
            if (!isPresent(arrayC, elemA) && isPresent(arrayB, elemA)) {
                arrayC[idx] = elemA;
                idx++;
            }
        }
        return arrayC;

    }

    static int[] union(int[] arrayA, int[] arrayB) {
        int[] arrayC = new int[arrayA.length + arrayB.length];
        int idx = 0;
        for (int elemA : arrayA) {
            arrayC[idx] = elemA;
            idx++;
        }
        for (int elemB : arrayB) {
            if (!isPresent(arrayC, elemB)) {
                arrayC[idx] = elemB;
                idx++;
            }
        }
        return arrayC;

    }

    static boolean isPresent(int[] array, int element) {
        for (int i = 0; i < array.length; i++) {
            if (array[i] == element) {
                return true;

            }
        }
        return false;
    }

}