package list;

public class Findpair extends DoublyLinkedList {
    public void sumOfPair(int k) {
        Node currA = head;
        Node currB = head.next;
        while (currA != null) {
            currB = currA.next;
            while (currB != null) {
                if (currA.data + currB.data == k) {
                    System.out.println("Found pairs: " + currA.data + ", " + currB.data);
                    return;
                }
                currB = currB.next;
            }
            currA = currA.next;
        }
    }

    public static void main(String[] args) {
        Findpair list = new Findpair();
        list.insertAtEnd(2);
        list.insertAtEnd(3);
        list.insertAtEnd(4);
        list.insertAtEnd(11);
        list.insertAtEnd(6);
        list.insertAtEnd(9);
        list.sumOfPair(10);

    }
}
