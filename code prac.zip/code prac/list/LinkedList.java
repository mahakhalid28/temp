package list;

public class LinkedList {
    Node head;
    Node tail;

    class Node {
        String data;
        Node next;

        Node(String data) {
            this.data = data;
            this.next = null;
        }

        Node(String data, Node next) {
            this.data = data;
            this.next = next;
        }
    }

    public void addAtStart(String data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            tail = newNode;
        } else {
            newNode.next = head;
            head = newNode;
        }
    }

    public void addAtLast(String data) {
        Node newNode = new Node(data);
        if (tail == null) {
            head = newNode;
            tail = newNode;
        } else {
            tail.next = newNode;
            tail = newNode;
        }
    }

    public void addAt(int pos, String data) {
        if (pos == 0) {
            addAtStart(data);
            return;
        }
        int index = 0;
        Node cursor = head;
        Node prev = null;
        while (index != pos && cursor != null) {
            prev = cursor;
            cursor = cursor.next;
            index++;
        }
        if (index != pos) {
            System.out.println("Cannot insert at this position");
            return;
        }

        Node newNode = new Node(data);

        prev.next = newNode;
        newNode.next = cursor;
        if (cursor == null) {
            tail = newNode;
        }
    }

    public void deleteAtStart() {
        if (head == null) {
            System.out.println("List is empty");
            return;
        }
        if (head.next == null) {
            head = null;
            tail = null;
            return;
        }
        head = head.next;
    }

    public void deleteAtEnd() {
        if (tail == null) {
            System.out.println("List is empty");
            return;
        }
        if (head.next == null) {
            head = null;
            tail = null;
            return;
        }
        Node prev = head;
        while (prev.next != tail) {
            prev = prev.next;
        }
        tail = prev;
        tail.next = null;
    }

    public void deleteAt(int pos) {
        if (pos == 0) {
            deleteAtStart();
            return;
        }
        int index = 0;
        Node cursor = head;
        Node prev = null;
        while (index != pos && cursor.next != null) {
            prev = cursor;
            cursor = cursor.next;
            index++;
        }
        if (index != pos) {
            System.out.println("Cannot delete at this position");
            return;
        }
        // Node prev = head;
        // while (prev.next != cursor) {
        // prev = prev.next;
        // }

        prev.next = cursor.next;
        // cursor.next = prev;
        if (cursor.next == null) {
            tail = prev;
        }
    }

    public Node search(String data) {
        Node cur = head;
        while (cur != null && !cur.data.equals(data)) {
            cur = cur.next;
        }
        return cur;
    }

    public int size() {
        Node current = head;
        int length = 0;
        while (current != null) {
            current = current.next;
            length++;

        }
        return length;

    }

    public void display() {
        Node cursor = head;
        while (cursor != null) {
            System.out.print(cursor.data + "->");
            cursor = cursor.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        LinkedList list = new LinkedList();
        list.addAt(0, "A");
        list.addAt(1, "B");
        list.addAt(2, "C");
        list.addAt(1, "D");
        list.addAtLast("E");
        list.addAtStart("F");
        System.out.println("Original List:");
        list.display();

        list.deleteAtStart();
        System.out.println("After Deleteting At Start:");
        list.display();
        list.deleteAtEnd();
        System.out.println("After Deleteting At End:");
        list.display();
        System.out.println("After Deletetin At 1st:");
        list.deleteAt(1);
        list.display();

        LinkedList.Node node = list.search("D");
        if (node != null)
            System.out.println(node.data);
    }
}
