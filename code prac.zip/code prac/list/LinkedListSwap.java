package list;

public class LinkedListSwap extends LinkedList {

    public void swapNodes(Node x, Node y) {
        if (x == y)
            return;

        Node prevX = null, currX = head;
        while (currX != null && currX != x) {
            prevX = currX;
            currX = currX.next;

        }

        Node prevY = null, currY = head;
        while (currY != null && currY != y) {
            prevY = currY;
            currY = currY.next;
        }
        if (currX == null || currY == null) {
            return;
        }
        if (prevX != null) {
            prevX.next = currY;
        } else {
            head = currY;
        }

        if (prevY != null) {
            prevY.next = currX;
        } else {
            head = currX;
        }

        Node temp = currX.next;
        currX.next = currY.next;
        currY.next = temp;
    }

    public void swapKthNode(int k) {
        Node x = null, y = null;
        Node current = head;
        int count = 1;
        int size = size();
        while (current != null) {
            if (count == k) {
                x = current;
            } else if (count == size - k + 1) {
                y = current;
            }
            current = current.next;
            count++;
        }
        swapNodes(x, y);
        // String temp = x.data;
        // x.data = y.data;
        // y.data = temp;
    }

    public static void main(String[] args) {
        LinkedListSwap list = new LinkedListSwap();
        list.addAtLast("7");
        list.addAtLast("4");
        list.addAtLast("9");
        list.addAtLast("3");
        list.addAtLast("11");
        list.addAtLast("8");
        list.display();
        list.swapKthNode(5);
        list.display();

    }
}
