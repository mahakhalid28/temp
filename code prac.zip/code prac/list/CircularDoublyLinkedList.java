package list;

public class CircularDoublyLinkedList extends CircularDoubly {

    public void deleteDuplicateNodes() {
        Node currA = head;
        Node currB = head.next;
        while (currA.next != head) {
            currB = currA.next;
            while (currB.next != head) {
                Node nextB = currB.next;// when we delete B we cant find next B thats why we write this to store next B
                if (currA.data == currB.data) {
                    deleteAtLocation(currB);
                }
                currB = nextB;
            }
            if (currA.data == currB.data) {
                deleteAtLocation(currB);
            }
            currA = currA.next;
        }

    }

    public static void main(String[] args) {
        CircularDoublyLinkedList list = new CircularDoublyLinkedList();

        list.insertAtEnd(0);
        list.insertAtEnd(1);
        list.insertAtEnd(0);
        list.insertAtEnd(2);
        list.insertAtEnd(0);
        list.display();
        list.deleteDuplicateNodes();
        list.display();
    }

}
