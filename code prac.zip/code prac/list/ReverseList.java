package list;

public class ReverseList extends LinkedList {
    // Node head;
    // Node tail;

    // class Node {
    // int data;
    // Node next;

    // public Node(int data) {
    // this.data = data;
    // this.next = null;

    // }

    // }
    public Node reverseAt(Node node) {
        Node prev = null;
        Node curr = node;
        while (curr != null) {
            Node Temp = curr.next;
            curr.next = prev;
            prev = curr;
            curr = Temp;
        }
        node.next = null;
        return prev;
    }

    public void reverse() {
        Node newHead = reverseAt(head);
        tail = head;
        head = newHead;

        // Node prev = null;
        // Node curr = head;
        // while (curr != null) {
        // Node Temp = curr.next;
        // curr.next = prev;
        // prev = curr;
        // curr = Temp;
        // }
        // tail = head;
        // head = prev;
        // tail.next = null;
    }

    public Node findMiddle() {
        Node slow = head, fast = head;
        while (fast != null && fast.next != null && fast.next.next != null) {
            slow = slow.next;
            fast = fast.next.next;
        }
        return slow;
    }

    public boolean isPalindrome() {
        Node middle = findMiddle();
        Node secondHead = reverseAt(middle.next);
        Node currFirst = head;
        Node currSecond = secondHead;
        while (currSecond != null && currFirst != middle.next) {
            System.out.printf("First: %s, Second: %s\n", currFirst.data, currSecond.data);
            if (currFirst.data != currSecond.data)
                return false;
            currFirst = currFirst.next;
            currSecond = currSecond.next;
        }
        return true;
    }

    public static void main(String[] args) {
        ReverseList list = new ReverseList();
        list.addAtLast("0");
        list.addAtLast("1");
        list.addAtLast("2");
        list.addAtLast("5");
        list.addAtLast("2");
        list.addAtLast("1");
        list.addAtLast("6");
        Node middleNode = list.findMiddle();
        System.out.println("Middle Node: ");
        System.out.println(middleNode.data);
        System.out.println("Original List: ");
        list.display();
        System.out.println("Reversed List: ");
        list.reverse();
        list.display();
        System.out.println("Is List Palindrome: ");
        System.out.println(list.isPalindrome());

    }

}
