package list;

public class SplitLists {
    Node head;
    Node tail;

    class Node {
        String data;
        Node next;

        public Node(String data) {
            this.data = data;
            this.next = null;
        }
    }

    public void addAtLast(String data) {
        Node newNode = new Node(data);
        if (head == null || tail == null) {
            head = newNode;
            tail = newNode;
            newNode.next = head;
            return;
        }
        tail.next = newNode;
        tail = newNode;
        newNode.next = head;

    }

    public void display() {
        Node current = head;
        while (current.next != head) {
            System.out.print(current.data + "->");
            current = current.next;
        }
        System.out.println(current.data + "");

    }

    public SplitLists splitAt(String atData) {
        Node current = head;
        Node newHead;

        while (current.data != atData) {
            current = current.next;
        }
        newHead = current.next;
        current.next = head;
        current = newHead;
        while (current.next != head) {
            current = current.next;
        }
        current.next = newHead;
        SplitLists list2 = new SplitLists();
        list2.head = newHead;
        list2.tail = current;
        return list2;

    }

    public static void main(String[] args) {
        SplitLists list = new SplitLists();
        list.addAtLast("A");
        list.addAtLast("B");
        list.addAtLast("C");
        list.addAtLast("D");
        list.addAtLast("E");
        list.display();
        SplitLists list2 = list.splitAt("C");
        list.display();
        list2.display();
        list2.addAtLast("F");
        list2.display();
    }

}