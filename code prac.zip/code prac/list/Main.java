package list;

public class Main {
    Node head;

    class Node {
        String data;
        Node next;

        Node(String data) {
            this.data = data;
            this.next = null;

        }
    }

    public void addAtStart(String data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            return;

        }
        newNode.next = head;
        head = newNode;

    }

    public void addAtLast(String data) {

    }

    public static void main(String[] args) {
        Main list = new Main();
        list.addAtStart("M");
        list.addAtStart("is");

        // linkedlist l1 = new linkedlist(2);
        // l1.add(3);
        // l1.add(4);
        // l1.add(5);

        // System.out.println();

        // }
    }
}
