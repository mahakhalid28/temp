package list;

public class NavigatorLL {
    class Webpage {
        String url;
        Webpage prev;
        Webpage nxt;

        Webpage(String url) {
            this.url = url;
            this.prev = null;
            this.nxt = nxt;

        }

    }

    Webpage tail;
    Webpage head;
    Webpage current;
    String url;

    NavigatorLL() {
        head = tail = current = null;
        url = "blank";

    }

    public void visit(String url) {
        Webpage n = new Webpage(url);
        if (head == null) {
            head = n;
            tail = n;
            current = n;

        } else {
            tail.nxt = n;
            n.prev = tail;
            tail = n;

        }
        current = n;

    }

    public void back() {
        current = current.prev;
        System.out.println("currently visiting " + current.url);

    }

    public void forward() {
        current = current.nxt;
        System.out.println("current" + current.url);
    }

    public static void main(String[] args) {
        NavigatorLL ll = new NavigatorLL();
        ll.visit("Youtube");
        ll.visit("W3Schl");
        ll.visit("linker");
        ll.back();

    }

}
