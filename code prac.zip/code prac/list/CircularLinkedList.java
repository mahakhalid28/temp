package list;

public class CircularLinkedList {
    Node head;
    Node tail;

    class Node {
        int data;
        Node next;

        public Node(int data) {
            this.data = data;
        }

    }

    public void addAtLast(int data) {
        Node newNode = new Node(data);
        if (head == null && tail == null) {
            head = newNode;
            tail = newNode;
            newNode.next = head;
        }
        tail.next = newNode;
        tail = newNode;
        newNode.next = head;
    }

    public void evenOddSumm() {
        int count = 1;
        int evenSum = 0;
        int oddSum = 0;
        Node current = head;
        while (current.next != head) {
            if (count % 2 == 0) {
                evenSum += current.data;
            } else {
                oddSum += current.data;
            }
            current = current.next;
            count++;
        }
        if (count % 2 == 0) {
            evenSum += current.data;
        } else {
            oddSum += current.data;
        }

        head.data = evenSum;
        tail.data = oddSum;
    }

    public void display() {
        Node curr = head;
        while (curr.next != head) {
            System.out.print(curr.data + "->");
            curr = curr.next;
        }
        System.out.println(curr.data);
    }

    public static void main(String[] args) {
        CircularLinkedList list = new CircularLinkedList();
        list.addAtLast(7);
        list.addAtLast(11);
        list.addAtLast(9);
        list.addAtLast(3);
        list.addAtLast(4);
        list.addAtLast(8);
        list.display();
        list.evenOddSumm();
        list.display();
    }

}
