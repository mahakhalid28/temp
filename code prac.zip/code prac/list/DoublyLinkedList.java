package list;

public class DoublyLinkedList {
  Node head;
  Node tail;

  class Node {
    int data;
    Node next;
    Node previous;

    Node(int d) {
      this.data = d;
      next = null;
      previous = null;
    }
  }

  // Function to delete a node from the doubly linked list
  public void deleteNode(Node current) {
    if (head == null || current == null) {
      return;
    }

    // Case 1: If the node to be deleted is the head node
    if (current == head) {
      head = head.next;
      if (head != null) {
        head.previous = null;
      } else {
        tail = null; // If head is the only node in the list
      }
      return;
    }

    // Case 2: If the node to be deleted is in the middle of the list
    if (current.next != null) {
      current.previous.next = current.next;
      current.next.previous = current.previous;
      return;
    }

    // Case 3: If the node to be deleted is the tail node
    if (current == tail) {
      tail = tail.previous;
      if (tail != null) {
        tail.next = null;
      } else {
        head = null; // If tail is the only node in the list
      }
    }
  }

  // function to find size of doubly linked list
  public int sizeOfDoublyLinkedList() {
    int count = 0;
    Node temp = head;
    while (temp != null) {
      count++;
      temp = temp.next;

    }
    return count;
  }

  public void swapNodes(int position) {
    int size = sizeOfDoublyLinkedList();
    if (position >= size) {
      System.out.println("position should be less than size");
      return;
    }
    Node tempHead = head;
    Node tempTail = tail;
    int i = 1;
    while (i < position) {
      tempHead = tempHead.next;
      tempTail = tempTail.previous;
      i++;

    }
    int swap = tempHead.data;
    tempHead.data = tempTail.data;
    tempTail.data = swap;

  }

  public void insertAtEnd(int newData) {
    Node newNode = new Node(newData);
    if (head == null) {
      head = newNode;
      tail = newNode;
      return;
    }

    Node current = head;
    while (current.next != null) {
      current = current.next;
    }
    current.next = newNode;
    newNode.previous = current;
    tail = newNode;
  }

  public void printDoublyLinkedList() {
    Node temp = head;
    while (temp != null) {
      System.out.print(temp.data + " ");
      temp = temp.next;
    }
    System.out.println();
  }

  public static void main(String[] args) {
    DoublyLinkedList list = new DoublyLinkedList();
    list.insertAtEnd(5);
    list.insertAtEnd(2);
    list.insertAtEnd(4);
    list.insertAtEnd(8);
    list.insertAtEnd(9);
    list.insertAtEnd(3);
    list.printDoublyLinkedList();
    list.swapNodes(5);
    list.printDoublyLinkedList();

  }

}
