package list;

public class CircularDoubly {
    Node head;
    Node tail;

    class Node {
        int data;
        Node next;
        Node previous;

        public Node(int data) {
            this.data = data;
        }

    }

    public void insertAtEnd(int data) {
        Node newNode = new Node(data);
        if (head == null && tail == null) {
            head = newNode;
            tail = newNode;
            newNode.next = head;
        } else {
            tail.next = newNode;
            // tail = newNode;
            newNode.previous = tail;
            // newNode.next = head;
            tail = newNode;
        }
        tail.next = head;
        head.previous = tail;

    }

    public void deleteAtStart() {
        Node temp = head;
        head = temp.next;
        tail.next = head;
        head.previous = tail;
    }

    public void deleteNodeAtEnd() {
        tail = tail.previous;
        tail.next = head;
        head.previous = tail;
    }

    public void deleteAtLocation(Node current) {
        if (current == head) {
            deleteAtStart();
        } else if (current.next != head) {
            current.previous.next = current.next;
            current.next.previous = current.previous;
            return;
        } else {
            deleteNodeAtEnd();
        }

    }

    public void display() {
        Node curr = head;
        while (curr.next != head) {
            System.out.print(curr.data + "->");
            curr = curr.next;
        }
        System.out.println(curr.data);
    }

    public static void main(String[] args) {
        CircularDoubly list = new CircularDoubly();
        list.insertAtEnd(7);
        list.insertAtEnd(9);
        list.insertAtEnd(6);
        list.insertAtEnd(4);
        list.insertAtEnd(2);

        list.display();
        list.deleteNodeAtEnd();
        list.display();
        list.deleteAtStart();
        list.display();

    }

}
