import java.util.Stack;
import java.util.StringTokenizer;

public class InfixToPostfix {
    String exp;
    String output = "";
    Stack<String> s = new Stack<String>();

    public String convert(String exp) {
        StringTokenizer tokenizer = new StringTokenizer(exp);
        String token;
        while (tokenizer.hasMoreTokens()) {
            token = tokenizer.nextToken();
            if (token.equals("(")) {
                s.push("(");
            } else if (token.equals(")")) {
                String top = s.pop();
                while (!s.isEmpty() && !top.equals("(")) {
                    output = output + " " + top;
                    top = s.pop();
                }
            } else if (this.isOperator(token)) {
                while (!s.isEmpty() && this.isPrecedenceGreaterOrEq(s.peek(), token)) {
                    String top = s.pop();
                    output = output + " " + top;
                }
                s.push(token);
            } else {
                output = output + " " + token;
            }
        }
        while (!s.isEmpty()) {
            String top = s.pop();
            output = output + " " + top;
        }
        return output;

    }

    public boolean isOperator(String s) {
        if (s.equals("+") ||
                s.equals("-") ||
                s.equals("*") ||
                s.equals("/") ||
                s.equals("^"))
            return true;
        else {
            return false;
        }

    }

    public int precedence(String op) {
        if (op.equals("^"))
            return 3;
        else if (op.equals("*") || op.equals("/"))
            return 2;
        else if (op.equals("+") || op.equals("-"))
            return 1;
        else
            return 0;
    }

    public boolean isPrecedenceGreaterOrEq(String op1, String op2) {
        return precedence(op1) >= precedence(op2);
    }

}
