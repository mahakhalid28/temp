import java.util.Stack;
import java.util.StringTokenizer;

public class InfixToPostfix {
    String exp;
    String output = "";
    Stack<String> s = new Stack<String>();

    public String convert(String exp) {
        StringTokenizer tokenizer = new StringTokenizer(exp);
        String token;
        while (tokenizer.hasMoreTokens()) {
            token = tokenizer.nextToken();
            if (token.equals("(")) {
                s.push("(");
            } else if (token.equals(")")) {
                String top = s.pop();
                while (!s.isEmpty() && !top.equals("(")) {
                    output = output + " " + top;
                    top = s.pop();
                }
            } else if (this.isOperator(token)) {
                while (!s.isEmpty() && this.isPrecedenceGreaterOrEq(s.peek(), token)) {
                    String top = s.pop();
                    output = output + " " + top;
                }
                s.push(token);
            } else {
                output = output + " " + token;
            }
        }
        while (!s.isEmpty()) {
            String top = s.pop();
            output = output + " " + top;
        }
        return output;

    }

    public boolean isOperator(String s) {
        if (s.equals("+") ||
                s.equals("-") ||
                s.equals("*") ||
                s.equals("/") ||
                s.equals("^"))
            return true;
        else {
            return false;
        }

    }

    public boolean isPrecedenceGreaterOrEq(String op1, String op2) {
        if (op1.equals(op2)) {
            return true;
        } else if (op1.equals("^")) {
            return true;
        } else if (op1.equals("+") && op2.equals("-")) {
            return true;
        } else if (op1.equals("-") && op2.equals("+")) {
            return true;
        } else if (op1.equals("*") && op2.equals("/")) {
            return true;
        } else if (op1.equals("/") && op2.equals("*")) {
            return true;
        } else if ((op1.equals("*") || op1.equals("/"))
                && (op2.equals("+") || op2.equals("-"))) {
            return true;
        } else {
            return false;
        }
    }

}
