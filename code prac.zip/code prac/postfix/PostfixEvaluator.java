package postfix;

import java.util.ArrayList;
import java.util.StringTokenizer;
import stack.Stack;

public class PostfixEvaluator {
    private String expression;

    public PostfixEvaluator(String expression) {
        this.expression = expression;

    }

    public String getExpression() {
        return expression;
    }

    public void setExpression(String expression) {
        this.expression = expression;
    }

    private ArrayList<String> tokenizeExpression() {
        StringTokenizer tokenizer = new StringTokenizer(this.expression);
        ArrayList<String> tokens = new ArrayList<>();
        while (tokenizer.hasMoreTokens()) {
            tokens.add(tokenizer.nextToken());
        }

        return tokens;

    }

    private boolean isOperator(String s) {
        if (s.equals("+") || s.equals("*")) {
            return true;
        } else {
            return false;
        }

    }

    private int applyOperator(String op, int num1, int num2) {
        if (op.equals("+"))
            return num1 + num2;
        else if (op.equals("*"))
            return num1 * num2;
        else
            throw new RuntimeException("wrong operator WARNING");
    }

    public int evaluate() {
        ArrayList<String> tokens = tokenizeExpression();
        Stack s = new Stack();
        for (String tok : tokens) {
            if (isOperator(tok)) {
                int num1 = s.pop();
                int num2 = s.pop();
                int result = applyOperator(tok, num1, num2);
                s.push(result);

            } else {
                int num = Integer.parseInt(tok);
                s.push(num);

            }
        }

        return s.pop();

    }

}
