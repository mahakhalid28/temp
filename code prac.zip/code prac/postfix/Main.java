package postfix;

public class Main {
    public static void main(String[] args) {
        String x = "4 6 + 2 3 * +";
        PostfixEvaluator eval = new PostfixEvaluator(x);
        System.out.println(eval.evaluate());
    }

}
