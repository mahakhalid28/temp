import java.util.ArrayList;
import java.util.Arrays;

class Mylist {
    int array[];

    Mylist(int array[]) {
        this.array = array;
    }

    public void insertAt(int position, int value) {
        int[] newArr = new int[array.length + 1];
        int i = 0, j = 0;
        while (i < array.length) {
            if (j == position) {
                newArr[j] = value;
                j++;
            } else {
                newArr[j] = array[i];
                i++;
                j++;

            }

        }
        this.array = newArr;
    }

    public String toString() {
        return Arrays.toString(this.array);
    }

    public void deleteAt(int position) {
        for (int i = 0; i < array.length - 1; i++) {
            if (i >= position) {
                array[i] = array[i + 1];

            }

        }
        array[array.length - 1] = 0;
    }

}

public class insert {

    public static void main(String[] args) {
        int a[] = { 5, 7, 1, 2 };
        Mylist list = new Mylist(a);
        System.out.println("Array before:");
        System.out.println(list);
        list.insertAt(1, -2);
        System.out.println("Array after:");
        System.out.println(list);

        list.deleteAt(2);
        ;
        System.out.println("Array after deleting at 2:");
        System.out.println(list);

    }
}