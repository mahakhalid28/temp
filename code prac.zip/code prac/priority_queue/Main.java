package priority_queue;

import java.lang.reflect.Array;
import java.util.Arrays;

class Data {
    int item;
    int priority;

    public Data(int item, int priority) {
        this.item = item;
        this.priority = priority;

    }

    public String toString() {
        return "" + priority;
    }
}

class PriorityQueue {
    Data[] queue = new Data[100];
    int back = 0;

    int findMinIndex() {
        int min = 0;
        for (int i = 0; i < back; i++) {

            if (queue[i].priority < queue[min].priority) {
                min = i;
            }
        }
        return min;
    }

    void enqueue(Data data) {
        if (back == queue.length) {
            System.out.println("Queue is full");
        } else {
            queue[back] = data;
            back = back + 1;

        }
    }

    Data dequeue() {
        if (back == 0) {
            System.out.println("queue is empty");
            return null;
        }

        int indexToRemove = findMinIndex();
        Data result = queue[indexToRemove];
        for (int i = indexToRemove; i < back; i++) {
            queue[i] = queue[i + 1];
        }
        back--;
        return result;
    }

    @Override
    public String toString() {
        String result = "";
        for (int i = 0; i < back; i++) {
            result += queue[i] + ",";
        }
        return result;
    }
}

public class Main {
    public static void main(String[] args) {
        PriorityQueue pq = new PriorityQueue();
        pq.enqueue(new Data(1, 3));
        pq.enqueue(new Data(1, 5));
        pq.enqueue(new Data(1, 1));
        pq.enqueue(new Data(1, 7));

        System.out.println("Priority Queue:");
        System.out.println(pq);
        System.out.println("Dequeue:");

        System.out.println(pq.dequeue());
        System.out.println("Priority Queue After Dequeue:");

        System.out.println(pq);
    }
}
