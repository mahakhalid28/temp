import java.util.Scanner;

class largestNumber {
    public static void main(String args[]) {
        // int x, y = 0, z = 0;
        // Scanner in = new Scanner(System.in);
        // x = in.nextInt();
        // y = in.nextInt();
        // z = in.nextInt();

        // if (x > y && x > z) {
        // System.out.println("x is largest");

        // } else if (y > x && y > z) {
        // System.out.println("y is largest");
        // } else if (z > x && z > y) {
        // System.out.println("z is largest");
        // }

        // else {
        // System.out.println("numbers are not distinct");

        // }
        // ======================================================

        // we have 100 elements and e want to find largest element from them
        int n, max;
        Scanner s = new Scanner(System.in);
        System.out.println("enter number of elements in array");
        n = s.nextInt();
        int a[] = new int[n];
        System.out.println("enter elements of array");
        for (int i = 0; i < n; i++) {
            a[i] = s.nextInt();

        }
        max = a[0];
        for (int i = 0; i < n; i++) {
            if (max < a[i]) {
                max = a[i];
            }
        }
        System.out.println("maximum value:" + max);

    }

}